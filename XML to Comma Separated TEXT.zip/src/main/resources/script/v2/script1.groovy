// This is Groovy Flowstep Version 2.x, running with Groovy runtime 4, Downgrade the script if older behaviour needed.

import com.sap.it.script.v2.api.Message
import groovy.util.XmlSlurper

Message processData(Message message) {

    String body = message.getBody(String)

    def xml = new XmlSlurper().parseText(body)

    StringBuilder txtOutput = new StringBuilder()

    xml.Order.each { order ->
        txtOutput.append(order.OrderId.text()).append(",")
        txtOutput.append(order.CustomerName.text()).append(",")
        txtOutput.append(order.Product.text()).append(",")
        txtOutput.append(order.Quantity.text()).append(",")
        txtOutput.append(order.Price.text())
        txtOutput.append("\n")
    }

    message.setBody(txtOutput.toString().trim())

    return message
}