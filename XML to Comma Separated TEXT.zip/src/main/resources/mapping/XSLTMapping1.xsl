<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet 
    version="1.0"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <!-- Output as text -->
    <xsl:output method="text" encoding="UTF-8"/>

    <xsl:template match="/">
        <xsl:for-each select="root/Order">
            <xsl:value-of select="OrderId"/>
            <xsl:text>,</xsl:text>
            <xsl:value-of select="CustomerName"/>
            <xsl:text>,</xsl:text>
            <xsl:value-of select="Product"/>
            <xsl:text>,</xsl:text>
            <xsl:value-of select="Quantity"/>
            <xsl:text>,</xsl:text>
            <xsl:value-of select="Price"/>
            <xsl:text>&#10;</xsl:text> <!-- New line -->
        </xsl:for-each>
    </xsl:template>

</xsl:stylesheet>